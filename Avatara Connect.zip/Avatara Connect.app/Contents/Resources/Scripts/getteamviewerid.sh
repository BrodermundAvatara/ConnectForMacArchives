#! /bin/bash

## This script returns the teamviewerid

defaults read ~/Library/Preferences/com.teamviewer.teamviewer.preferences.Machine.plist ClientID
