#! /bin/sh
osascript -e 'tell application "Finder" to get bounds of window of desktop'
