#! /bin/sh
osascript -e 'quit app "Avatara Connect"'
cd "/Applications"
rm -r  "Avatara Connect.app"
# rm -rf  "AvataraConnectMac"
curl -L -o "Avatara.zip" "https://ccconnect.avataracloud.com/connectformac"
unzip "Avatara.zip"
rm "Avatara.zip"
rm -rf "__MACOSX"
mv "/Applications/AvataraConnectMac/Avatara Connect.app" "/Applications/Avatara Connect.app"
rm -rf "AvataraConnectMac"
open "/Applications/Avatara Connect.app"